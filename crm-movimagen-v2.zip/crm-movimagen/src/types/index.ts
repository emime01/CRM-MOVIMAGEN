// ============================================================
// CRM Movimagen — Tipos TypeScript
// ============================================================

export type Rol =
  | 'vendedor'
  | 'asistente_ventas'
  | 'gerente_comercial'
  | 'operaciones'
  | 'arte'
  | 'administracion'

export type EstadoOrden =
  | 'borrador'
  | 'pendiente_aprobacion'
  | 'rechazada'
  | 'aprobada'
  | 'en_oic'
  | 'facturada'
  | 'cobrada'

export type EstadoLead =
  | 'nuevo'
  | 'en_conversacion'
  | 'propuesta_enviada'
  | 'negociacion'
  | 'ganado'
  | 'perdido'

export type EstadoReserva =
  | 'pendiente'
  | 'aprobada'
  | 'rechazada'
  | 'confirmada'
  | 'vencida'

export type TipoEvidencia = 'antes' | 'instalacion' | 'instalado' | 'grabado'
export type TipoMaterial  = 'foto' | 'video'
export type TipoReunion   = 'presencial' | 'virtual' | 'llamada' | 'email'
export type ResultadoReunion = 'positivo' | 'neutral' | 'negativo' | 'sin_respuesta'
export type Moneda        = 'USD' | 'UYU'
export type FacturarA     = 'agencia' | 'cliente_final'

// ── Entidades base ────────────────────────────────────────────

export interface Perfil {
  id: string
  user_id: string
  nombre: string
  rol: Rol
  porcentaje_comision: number
  activo: boolean
  created_at: string
}

export interface Cliente {
  id: string
  nombre: string
  empresa?: string
  email?: string
  telefono?: string
  rut?: string
  notas?: string
  activo: boolean
  created_at: string
}

export interface Agencia {
  id: string
  nombre: string
  email?: string
  telefono?: string
  rut?: string
  ejecutivo_cuenta?: string
  porcentaje_comision: number
  incluye_produccion: boolean
  notas?: string
  activo: boolean
  created_at: string
}

export interface Soporte {
  id: string
  nombre: string
  seccion?: string
  categoria: 'Digital' | 'Shopping' | 'Exterior' | 'Bus'
  tipo: 'led' | 'circuito' | 'estatico_bus' | 'banner_shopping' | 'estatico_shopping' | 'medianera'
  ubicacion: string
  precio_semanal: number
  costo_produccion?: number
  activo: boolean
}

// ── Órdenes ───────────────────────────────────────────────────

export interface OrdenVenta {
  id: string
  numero: number
  cotizacion_id?: string
  cliente_id: string
  agencia_id?: string
  vendedor_id: string
  compartida_con_id?: string
  facturar_a: FacturarA
  estado: EstadoOrden
  tiene_produccion: boolean
  tiene_digital: boolean
  es_canje: boolean
  incluir_reportes: boolean
  es_mensualizada: boolean
  monto_total?: number
  monto_mensualizado?: number
  moneda: Moneda
  forma_pago_arrend?: string
  comentario_arrend?: string
  forma_pago_prod?: string
  comentario_prod?: string
  fecha_alta_prevista?: string
  fecha_baja_prevista?: string
  validez?: string
  referencia?: string
  marca?: string
  motivo_rechazo?: string
  aprobado_por?: string
  aprobado_at?: string
  created_at: string
  updated_at: string
  // Relations
  cliente?: Cliente
  agencia?: Agencia
  vendedor?: Perfil
  compartida_con?: Perfil
  items?: OrdenItem[]
}

export interface OrdenItem {
  id: string
  orden_id: string
  soporte_id: string
  cantidad: number
  semanas: number
  salidas?: number
  segundos?: number
  precio_unitario?: number
  descuento_pct: number
  nota?: string
  requiere_grabado: boolean
  requiere_produccion: boolean
  estado_grabado: 'pendiente' | 'grabado'
  estado_produccion: 'pendiente' | 'en_produccion' | 'producido' | 'instalado'
  numero_bus?: string
  created_at: string
  // Relations
  soporte?: Soporte
}

// ── Pipeline comercial ────────────────────────────────────────

export interface Lead {
  id: string
  vendedor_id: string
  cliente_id?: string
  agencia_id?: string
  descripcion?: string
  monto_potencial?: number
  cuatrimestre?: string
  estado: EstadoLead
  motivo_perdida?: string
  reserva_id?: string
  notas?: string
  created_at: string
  updated_at: string
  // Relations
  cliente?: Cliente
  agencia?: Agencia
  vendedor?: Perfil
}

export interface Reunion {
  id: string
  vendedor_id: string
  cliente_id?: string
  agencia_id?: string
  lead_id?: string
  fecha: string
  tipo?: TipoReunion
  participantes?: string
  resumen?: string
  resultado?: ResultadoReunion
  proximo_paso?: string
  fecha_proximo_contacto?: string
  created_at: string
  // Relations
  cliente?: Cliente
  agencia?: Agencia
  lead?: Lead
}

export interface Objetivo {
  id: string
  vendedor_id: string
  cuatrimestre: string
  objetivo_monto: number
  created_at: string
}

export interface PotencialCliente {
  id: string
  vendedor_id: string
  cliente_id: string
  cuatrimestre: string
  monto_potencial: number
  notas?: string
  // Relations
  cliente?: Cliente
}

// ── Finanzas ──────────────────────────────────────────────────

export interface Pago {
  id: string
  orden_id: string
  monto: number
  fecha_pago: string
  metodo?: string
  numero_factura?: string
  notas?: string
  created_at: string
}

export interface Comision {
  id: string
  pago_id: string
  vendedor_id: string
  orden_id: string
  monto_base: number
  porcentaje: number
  monto_comision: number
  liquidada: boolean
  created_at: string
  // Relations
  vendedor?: Perfil
  orden?: OrdenVenta
}

export interface ComisionAgencia {
  id: string
  pago_id: string
  agencia_id: string
  orden_id: string
  monto_base: number
  porcentaje: number
  incluye_prod: boolean
  monto_comision: number
  liquidada: boolean
  created_at: string
  // Relations
  agencia?: Agencia
}

// ── Disponibilidad ────────────────────────────────────────────

export interface Reserva {
  id: string
  soporte_id: string
  lead_id?: string
  orden_id?: string
  cliente_id: string
  vendedor_id: string
  fecha_desde: string
  fecha_hasta: string
  estado: EstadoReserva
  aprobada_por?: string
  notas?: string
  created_at: string
  // Relations
  soporte?: Soporte
  cliente?: Cliente
}

// ── Config ────────────────────────────────────────────────────

export interface ConfigEntry {
  clave: string
  valor: string
  tipo: 'text' | 'number' | 'boolean' | 'json' | 'list'
  descripcion?: string
  seccion?: string
  updated_at: string
}

// ── Helpers de UI ─────────────────────────────────────────────

export const ESTADO_ORDEN_LABELS: Record<EstadoOrden, string> = {
  borrador:              'Borrador',
  pendiente_aprobacion:  'Pendiente aprobación',
  rechazada:             'Rechazada',
  aprobada:              'Aprobada',
  en_oic:                'En OIC',
  facturada:             'Facturada',
  cobrada:               'Cobrada',
}

export const ESTADO_ORDEN_COLOR: Record<EstadoOrden, string> = {
  borrador:             'badge-gray',
  pendiente_aprobacion: 'badge-amber',
  rechazada:            'badge-red',
  aprobada:             'badge-green',
  en_oic:               'badge-blue',
  facturada:            'badge-orange',
  cobrada:              'badge-green',
}

export const ESTADO_LEAD_LABELS: Record<EstadoLead, string> = {
  nuevo:             'Nuevo',
  en_conversacion:   'En conversación',
  propuesta_enviada: 'Propuesta enviada',
  negociacion:       'Negociación',
  ganado:            'Ganado',
  perdido:           'Perdido',
}

export const ROL_LABELS: Record<Rol, string> = {
  vendedor:           'Vendedor',
  asistente_ventas:   'Asistente de ventas',
  gerente_comercial:  'Gerente comercial',
  operaciones:        'Operaciones (OIC)',
  arte:               'Arte',
  administracion:     'Administración',
}
