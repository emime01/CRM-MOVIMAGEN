// ============================================================
// CRM Movimagen — Middleware de auth y roles
// ============================================================
import { withAuth } from 'next-auth/middleware'
import { NextResponse } from 'next/server'
import type { Rol } from '@/types'

// Rutas protegidas por rol
const PERMISOS: Record<string, Rol[]> = {
  '/dashboard/admin':       ['administracion'],
  '/dashboard/oic':         ['operaciones', 'gerente_comercial', 'asistente_ventas'],
  '/dashboard/arte':        ['arte', 'gerente_comercial'],
  '/dashboard/gerente':     ['gerente_comercial'],
  '/dashboard/config':      ['administracion', 'gerente_comercial'],
  '/dashboard/comisiones':  ['administracion'],
  '/dashboard/facturacion': ['administracion'],
}

export default withAuth(
  function middleware(req) {
    const { pathname } = req.nextUrl
    const rol = (req.nextauth.token as any)?.rol as Rol

    for (const [ruta, roles] of Object.entries(PERMISOS)) {
      if (pathname.startsWith(ruta) && !roles.includes(rol)) {
        return NextResponse.redirect(new URL('/dashboard', req.url))
      }
    }

    return NextResponse.next()
  },
  {
    callbacks: {
      authorized: ({ token }) => !!token,
    },
  }
)

export const config = {
  matcher: ['/dashboard/:path*'],
}
