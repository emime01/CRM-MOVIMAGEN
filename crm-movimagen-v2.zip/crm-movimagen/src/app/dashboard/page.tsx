export default function DashboardPage() {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--bg-app)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    }}>
      <div style={{ textAlign: 'center' }}>
        <div style={{
          fontFamily: 'Montserrat, sans-serif',
          fontSize: '22px',
          fontWeight: '800',
          color: 'var(--orange)',
          marginBottom: '8px',
        }}>
          MOVIMAGEN CRM
        </div>
        <p style={{ color: 'var(--gray-400)', fontSize: '14px' }}>
          Dashboard en construcción
        </p>
      </div>
    </div>
  )
}
