// ============================================================
// CRM Movimagen — NextAuth config
// src/app/api/auth/[...nextauth]/route.ts
// ============================================================
import NextAuth, { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import { createServiceClient } from '@/lib/supabase'

export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email:    { label: 'Email',     type: 'email' },
        password: { label: 'Contraseña', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) return null

        const supabase = createServiceClient()

        // Login con Supabase Auth
        const { data, error } = await supabase.auth.signInWithPassword({
          email:    credentials.email,
          password: credentials.password,
        })

        if (error || !data.user) return null

        // Obtener perfil con rol
        const { data: perfil } = await supabase
          .from('perfiles')
          .select('*')
          .eq('user_id', data.user.id)
          .single()

        if (!perfil || !perfil.activo) return null

        return {
          id:     perfil.id,
          email:  data.user.email!,
          name:   perfil.nombre,
          rol:    perfil.rol,
          userId: data.user.id,
        }
      },
    }),
  ],

  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.rol    = (user as any).rol
        token.userId = (user as any).userId
        token.perfilId = (user as any).id
      }
      return token
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).rol      = token.rol
        ;(session.user as any).userId  = token.userId
        ;(session.user as any).perfilId = token.perfilId
      }
      return session
    },
  },

  pages: {
    signIn: '/login',
  },

  session: {
    strategy: 'jwt',
    maxAge:   8 * 60 * 60, // 8 horas
  },

  secret: process.env.NEXTAUTH_SECRET,
}

const handler = NextAuth(authOptions)
export { handler as GET, handler as POST }
